import uuid
import pandas as pd
import json
import boto3
from boto3.dynamodb.conditions import Key
try:
    from journal.config_file import *
except ModuleNotFoundError:
    from src.journal.config_file import *
'''
*********WRITE DESIGN DECISIONS*********
'''


class AWS_CRUD_API(object):
    '''
    This object is an interface to the boto3 SDK which allows to make CRUD operations on the AWS
    Resources i.e. S3 and DynamoDB simultaneously 
    '''

    def __init__(self, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION, DYNAMO_DB_NAME, S3_BUCKET_NAME):

        boto_kwargs = {
            "aws_access_key_id": f"{AWS_ACCESS_KEY_ID}",
            "aws_secret_access_key": f"{AWS_SECRET_ACCESS_KEY}",
            "region_name": f"{AWS_REGION}"
        }

        botoSession = boto3.Session(**boto_kwargs)

        self.dynamodbClient: boto3.dynamodb = botoSession.resource(
            'dynamodb',
            region_name=f"{AWS_REGION}",
            aws_access_key_id=f"{AWS_ACCESS_KEY_ID}",
            aws_secret_access_key=f"{AWS_SECRET_ACCESS_KEY}"
        )

        self.dynamodbTable = self.dynamodbClient.Table(f'{DYNAMO_DB_NAME}')

        self.s3Client: boto3.s3 = botoSession.resource(
            's3',
            region_name=f"{AWS_REGION}",
            aws_access_key_id=f"{AWS_ACCESS_KEY_ID}",
            aws_secret_access_key=f"{AWS_SECRET_ACCESS_KEY}"
        )

        self.s3bucket = self.s3Client.Bucket(f'{S3_BUCKET_NAME}')

    def create_user_file(self, user: str, fileID: str, filename: str, file: json):
        '''
        Create the user file metadata on the specified DynamoDB and stores the file content
        as an S3 object with the file ID as key

        Returns: 
        * file with the correspondent file id

        Params:
        * user - should be the username of the user
        * fileID - should be a unique filename of the format < username/uuid.uuid4().hex >
        * filename - should be the filename of the resource that you want to store
        * file - should contain the content of the user file in json format
        '''

        fileInfo = {
            DYNAMO_TABLE_CONFIG['partition_key']: 'userFiles',
            DYNAMO_TABLE_CONFIG['sort_key']: fileID,
            'userID': str(user),
            'filename': filename
        }
        self.dynamodbTable.put_item(Item=fileInfo)
        self.s3bucket.put_object(Key=fileID, Body=file)

    def get_user_files(self, user: str):
        '''
        Get user files from the DynamoDB and use the file ID
        to retrieve the file content from S3

        Returns: 
        [ 
            { fileID : user99/143rjlrtb, filename : test_file.csv, ... file_content : { key : val,...} },
            { fileID : user99/143rjlrtb, filename : another_file.csv, ... file_content : { key : val,...} },
        ]

        Params:
        * user - should be the username of the user
        '''

        ########GET ALL THE USER FILES METADATA AND FILTER IT BY USERNAME #########
        response = self.dynamodbTable.query(KeyConditionExpression=Key(
            DYNAMO_TABLE_CONFIG['partition_key']).eq('userFiles'))
        user_files_info = list(filter(
            lambda item: item['userID'] == user, response['Items']))

        ######### APPEND ALL USER FILES FROM S3 USING FILE ID FROM DYNAMODB #####
        # USER FILES FORMAT
        # {'accountID': 'test-user99/dc92f1c3d43948d3828c79d2246118b7', 'content': {'0': {'0': 1, '1': 0, '2': 7}}}
        user_files = []
        user_files_ids = [file[DYNAMO_TABLE_CONFIG['sort_key']]
                          for file in user_files_info]

        for fileID in user_files_ids:
            object = self.s3Client.Object(f'{S3_BUCKET_NAME}', fileID)
            retrieved_object = object.get()['Body'].read().decode('utf-8')
            user_files.append(
                {DYNAMO_TABLE_CONFIG['sort_key']: fileID, 'content': json.loads(retrieved_object)})

        ####### CONSTRUCT THE RESPONSE #######################################
        response = []
        for file in user_files_info:
            response_file = file
            for file_content in user_files:
                if file[DYNAMO_TABLE_CONFIG['sort_key']] == file_content[DYNAMO_TABLE_CONFIG['sort_key']]:
                    response_file['file_content'] = file_content['content']
                    response.append(response_file)

        return response

    def update_user_file(self, user: str, filename: str, file: json):
        '''
        Update DynamoDB Items by replacing the old item wit the new file information

        Returns:
        * file with the correspondent file id

        Params:
        * user - should be the username of the user
        * filename - should be the filename of the resource that you want to store
        * fileInfo - should be a unique filename of the format < username/uuid.uuid4().hex >
        '''

        ####### DELETE MATCHING FILES GET FILE ID FROM FILENAME AND USERNAME###########
        fileID = self.get_file_id_from_filename(filename, user)
        self.delete_user_file(filename, user)

        ################### RECREATE USER FILE WITH NEW DATA ##########################
        self.create_user_file(user, fileID, filename, file)

    def delete_user_file(self, filename: str, user: str):
        '''
        Delete file metadata from DynamoBD Items

        Returns:
        file with the correspondent file id

        Params:
        * user - should be the username of the user
        * filename - should be a filename of the format < username/uuid.uuid4().hex >
        '''

        fileID = self.get_file_id_from_filename(filename, user)
        if fileID == []:
            return None
        fileInfo = {
            DYNAMO_TABLE_CONFIG['partition_key']: 'userFiles',
            DYNAMO_TABLE_CONFIG['sort_key']: fileID,
        }
        self.dynamodbTable.delete_item(Key=fileInfo)

    def get_file_id_from_filename(self, filename: str, user:str):
        # if the file does not exists return an empty list
        try:
            return list(filter(lambda file: file['filename'] == filename, self.get_user_files(user)))[0][DYNAMO_TABLE_CONFIG['sort_key']]
        except IndexError:
            return []


#TODO: DELETE - S3 Objects ############
# Current attempt
# def delete_file_fromS3(fileID):
#     response = s3bucket.delete_objects(Delete={
#         'Objects': [
#             {
#                 'Key': fileID,
#             }
#         ]})
#     return response
# ERROR -> Issue#13
# TODO: ####### UPDATE - Dynamodb Item #########
# fileData = {
#     DYNAMO_TABLE_CONFIG['partition_key']: 'userFiles',
#     DYNAMO_TABLE_CONFIG['sort_key']: fileID,
# }
# self.dynamodbTable.update_item(Key=fileData, AttributeUpdates=fileInfo)

# TODO: write design description and clean config_file
# TODO: create a function to get IDS from filenames
# TODO: find a way to handle multiple files with the same name
