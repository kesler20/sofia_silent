AWS_ACCESS_KEY_ID = 'AKIA4YMASUARXKBQI4D3'

AWS_SECRET_ACCESS_KEY = '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'

AWS_REGION = 'eu-west-2'

# to update the following section, go on the followig link https://eu-west-2.console.aws.amazon.com/amplify/home?region=eu-west-2#/
# and look for the backend of the current application, then go on the cognito user pool
USER_POOL_ID = 'eu-west-2_41z8aLc9G'

S3_BUCKET_NAME = 'test-20220728140647-hostingbucket-dev'

DYNAMO_TABLE_CONFIG = {
    'partition_key': 'topic',
    'sort_key': 'accountID',
    'user_auth_key': 'username'
}

DYNAMO_DB_NAME = 'dynamo28f97260-dev'

BACKEND_URL = 'https://test-journal-back-end.herokuapp.com'

FRONT_END_URL = 'http://test-20220728140647-hostingbucket-dev.s3-website.eu-west-2.amazonaws.com'


