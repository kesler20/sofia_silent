'''**** RUN THIS SCRIPT ONLY WHEN THE CORS PERMISSIONS NEED TO BEE INITIALLY SET ****'''
# AWS related imports
import boto3
import json
try:
    from journal.config_file import *
except ModuleNotFoundError:
    from src.journal.config_file import *

if __name__ == "__main__":

    # Below are the keywords used to authenticate the API with AWS services (S3 and DynamoDB)
    # For these key words to work to authenticate the session make sure
    # whichever server environment you use has the correct environment variables set up
    # eg for Heroku command is:
    # <heroku config:set AWS_ACCESS_KEY_ID=example_key>
    boto_kwargs = {
        "aws_access_key_id": f"{AWS_ACCESS_KEY_ID}",
        "aws_secret_access_key": f"{AWS_SECRET_ACCESS_KEY}",
        "region_name": f"{AWS_REGION}"
    }

    # sets up the session with the access rights given by the account which the kwards refer to
    botoSession = boto3.Session(**boto_kwargs)
    # dynamodb table setup (for user info of uploaded files)
    dynamodb = botoSession.resource(
        'dynamodb',
        region_name=f"{AWS_REGION}",
        aws_access_key_id=f"{AWS_ACCESS_KEY_ID}",
        aws_secret_access_key=f"{AWS_SECRET_ACCESS_KEY}"
    )

    dynamodbtable = dynamodb.Table(f'{DYNAMO_DB_NAME}')
    dynamodb_output_table = dynamodb.Table(f'{DYNAMO_DB_NAME}')
    # s3 bucket setup (for storage of large userfiles)
    s3 = botoSession.resource(
        's3',
        region_name=f"{AWS_REGION}",
        aws_access_key_id=f"{AWS_ACCESS_KEY_ID}",
        aws_secret_access_key=f"{AWS_SECRET_ACCESS_KEY}"
    )

    s3bucket = s3.Bucket(f'{S3_BUCKET_NAME}')

    response = s3.BucketCors(f'{S3_BUCKET_NAME}').put(
        CORSConfiguration={
            'CORSRules': [
                {
                    'AllowedHeaders': ['Authorization', 'Content-Length'],
                    'AllowedMethods': ['GET', 'POST', 'HEAD', 'PUT'],
                    'AllowedOrigins': [f'{BACKEND_URL}', f'{FRONT_END_URL}', 'http://127.0.0.1:8000', 'http://127.0.0.1:3000'],
                    'MaxAgeSeconds': 3000
                }
            ]
        }
    )

    print(response)

    bucket_policy = {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "AddCannedAcl",
                "Effect": "Allow",
                "Principal": {
                    "AWS": "arn:aws:iam::876979855395:user/user"
                },
                "Action": "s3:*",
                "Resource": "arn:aws:s3:::test-20220728140647-hostingbucket-dev"
            }
        ]
    }

    response = s3.put_bucket_policy(Bucket=S3_BUCKET_NAME,
                                    Policy=json.dumps(bucket_policy))
    
    print(response)
