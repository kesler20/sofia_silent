import matplotlib.pyplot as plt
import pandas as pd
import json
from io import BytesIO
import tempfile

# create a class called calculator and one called data formatter
def convert_dict_list_to_df(data_set: 'list[dict]'):
    df_data = {key: [val[key] for val in data_set]
               for key in data_set[0].keys()}
    return pd.DataFrame(data=df_data)


def calculate_SMA(data_set: 'list[dict]',n: int, data_set_size: int):
    '''Calculates a range of simple moving averages from the list of dictionaries
    
    return a data frame containing all the moving averages 
    
    data_set - list of dictionaries which can be passed to pd.DataFrame data param
    n - number of moving averages which will also correspond to their window size
    data_set_size - number of x_values returned from the last instance'''
    print(data_set)
    df = convert_dict_list_to_df(data_set)
    x_value_size = len(df['x_value'])
    cols = list(df.columns.values)
    cols.remove('x_value') 
    df.set_index('x_value')

    for i in range(n):
        df[f'SMA{i}'] = df['total_1'].rolling(i).mean()
    
    df.drop(cols,axis=1,inplace=True)
    return df[-1*(x_value_size - data_set_size):-1]

def calculate_trend_bounds(data_set: 'list[dict]'):
    df = convert_dict_list_to_df(data_set).set_index('x_value')
    cols = list(df.columns.values) 
    for i in range(100):
        df[f'trend_1_Upper_{i}'] = df['trend_1'] + i
        df[f'trend_1_Lower_{i}'] = df['trend_1'] - i
    df.drop(cols,axis=1, inplace=True)
    return df

def ANOVA():
    pass

def get_metadata(df: pd.DataFrame, user):
    '''Returns the pandas data frame meta data'''
    columns = list(df.columns.values)

    dataTypes = df.dtypes
    dataTypes = [str(columnType) for columnType in dataTypes.to_list()]

    columnAndType = json.dumps(dict(zip(columns, dataTypes)))

    numRows, numColumns = df.shape
    return {}


def check_for_datetime(df: pd.DataFrame):
    '''checks if any of the csv columns read as strings 
    (ie pandas "objects") are in fact datetime/timestamps

    by passing a data frame you will get a dataframe 
    the datetime column will be turned into datetime if detected
    using pd.to_datetime(df[col])
    '''
    for col in df.columns:
        if df[col].dtype == 'object':
            try:
                df[col] = pd.to_datetime(df[col])
            except ValueError:
                pass
    return df


def convert_tempfile_to_IO(spooled_temp_file: tempfile.SpooledTemporaryFile):
    '''Convert SpooledTemporaryFile() file to IO object to be passed to 
    pandas dataframe or other file readers'''

    with spooled_temp_file.file as f:
        bytes_content = f.read()
        file_content = BytesIO(bytes_content).read()
    return file_content
