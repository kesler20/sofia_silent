# journal-backend
This repository contains the source code of the backend of the Jounral application v0.0
this can be installed from the root directory as a package journal==0.0.0 by running the following command

to run the backend run 
gunicorn --workers 3 -k uvicorn.workers.UvicornWorker --threads 2 src.journal.main:app

##### Dev instructions
all contributors should run tests which may ber run automatically on commit by using the following command

the pytest package looks for all the directories named tests within the src directory and within the tests directory any function with test_ at the start

the -e flag allows you to install the package from the current directory in editable mode
this will install all the dependencies of the package and put a link from the virtual environment to the actual source code directory, that way if you make a change to the file you don't need to reinstall the package

a linter can be used to perform static analysis before making commits i.e. flake8 
by running the following command

and a type checking is provided by mypy which cn be run from the following command

for making sure that the package works in different versions of python we use tox
the tox.ini file specifies a routine which can be run by tox consisting of setting up and installing
the journal package for different virtual environments with different versions of python
if you are on linux run 

if you do not have old versions of python installed run 
sudo apt-get install python3.8
sudo apt-get install python3.9

